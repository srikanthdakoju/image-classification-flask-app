from setuptools import setup
from setuptools import find_packages

setup(
    name="datascienceanywhere",
    version='1.0.0',
    author='Data Science Anywhere',
    author_email='datascienceanywhere@gmail.com',
    install_requires = [],
    packages =find_packages(include='datascienceanywhere')

)